from django.apps import AppConfig


class ObmsBasicsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'OBMS_basics'
