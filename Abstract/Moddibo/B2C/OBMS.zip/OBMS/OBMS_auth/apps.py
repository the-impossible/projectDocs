from django.apps import AppConfig


class ObmsAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'OBMS_auth'
