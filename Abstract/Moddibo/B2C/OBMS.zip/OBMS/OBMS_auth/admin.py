# My Django imports
from django.contrib import admin

# My App imports
from OBMS_auth.models import Accounts

# Register your models here.
admin.site.register(Accounts)